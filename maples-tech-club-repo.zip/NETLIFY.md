# Deploying to Netlify

|  |  |
|---|---|
| Project | **mtc-plan** |
| Owner | **CODEEX** |
| Site ID | `f0cefa6c-f197-4429-89cf-e4790a1675cd` |
| Publish directory | `maples-tech-club` |
| Live address | `https://mtc-plan.netlify.app` |

Everything below is already configured in the repository. Pick one of the three
routes; they all produce the same site.

---

## Route 1 — the CLI (recommended)

One command, and the Site ID is already baked into the script.

```bash
NETLIFY_AUTH_TOKEN=xxxxx ./deploy-netlify.sh --prod
```

Leave off `--prod` to get a draft preview URL first and look at it before
publishing.

Token: <https://app.netlify.com/user/applications#personal-access-tokens> →
**New access token**.

`deploy-netlify.sh` builds the site, then checks it *before* uploading
anything: all eight files present, PDF is 12 pages, dated 12 October 2026, and
the rupee sign renders. If any check fails it stops and the live site is left
alone.

It deploys with `--no-build`. That is on purpose — a manual Netlify deploy
never runs a build command anyway, so building locally means a broken build
fails on your machine instead of taking the site down.

---

## Route 2 — drag and drop, no token

Open <https://app.netlify.com/drop> and drop **`mtc-plan-netlify-drop.zip`**
(130 KB) onto the page. Nothing to install, no token.

To send it to the existing **mtc-plan** project rather than creating a new one,
go instead to:

```
https://app.netlify.com/projects/mtc-plan/deploys
```

and drop the zip in the upload area at the bottom.

The zip contains `_headers` and `_redirects`, so the tidy URLs and the PDF
headers work here exactly as they do on the other two routes.

---

## Route 3 — connect the Git repository

In the Netlify UI: **Project configuration → Build & deploy → Continuous
deployment → Link repository**.

Do not type the build settings in by hand. `netlify.toml` already sets them:

```toml
[build]
  command = "pip install -r requirements.txt && python build_site.py"
  publish = "maples-tech-club"

[build.environment]
  PYTHON_VERSION = "3.12"
```

If the UI already has stale settings from an earlier attempt, clear them —
`netlify.toml` wins, but blank fields avoid confusion later.

This route needs the repository to be on GitHub first. See `PUSH_TO_GITHUB.md`.

---

## Why the build works without `apt-get`

The PDF prints `₹` and `☐`. Neither exists in the PDF core fonts, so
`build_pdf.py` embeds DejaVu.

Previously the GitHub Actions workflow did `apt-get install fonts-dejavu-core`.
**Netlify build containers have no `sudo`,** so that approach would have failed
there.

Both fonts are now committed in `fonts/` and `build_pdf.py` searches that
folder *first*, ahead of every system path. The build therefore needs no root,
no font package, and produces identical output on any machine.

Verified in a clean room with every system font path removed: 12 pages, rupee
renders, 6,592 words — identical to the normal build.

The GitHub Actions workflow now uses the vendored fonts too, so both pipelines
do exactly the same thing.

---

## What gets published

| File | Purpose |
|---|---|
| `index.html` | Home |
| `about.html` | The club charter |
| `benefits.html` | Every free programme, with official links |
| `registration.html` | The eight-phase registration roadmap |
| `join.html` | Two-step selection, code of conduct |
| `proposal.html` | Summary of the application, PDF download |
| `404.html` | Not-found page. Carries `<base href="/">` so its links work at any depth |
| `Maples_Tech_Club_Proposal_Principal.pdf` | The 12-page proposal |
| `_headers` | Security headers; PDF opens inline; HTML never cached stale |
| `_redirects` | Extensionless URLs plus `/pdf` and `/apply` |

Routes verified: `/`, `/about`, `/benefits`, `/registration`, `/join`,
`/proposal`, `/pdf`, `/apply`, each `.html` form, and a missing path correctly
serving the 404.

### Short links

`/pdf` goes straight to the proposal and `/apply` to the join page — both short
enough to write on a notice board:

```
mtc-plan.netlify.app/apply
```

---

## Things that will trip you up

**The posters are not part of the website.** `build_poster.py` needs Playwright
and a headless Chromium. It is excluded from `requirements.txt` on purpose, and
Netlify must never try to run it. Posters are built locally and committed as
finished PDF and PNG files.

**`maples-tech-club/` is committed, and that is intentional.** Routes 1 and 2
upload the folder without building, so it has to exist in the repository. After
changing any build script, run `python3 build_site.py` and commit the result,
or the deployed site will lag behind the source.

**The PDF date is pinned.** `APP_DATE_OVERRIDE = "12 October 2026"` near the top
of `build_pdf.py`. Nothing re-dates itself; redeploying does not change it. Set
it to `None` to go back to auto-dating from the Indian clock.

**Python version.** Netlify's default is `3.x`. `netlify.toml` pins 3.12 because
it ships precompiled and installs in seconds. Some versions are compiled from
source and add two or three minutes to every deploy. `runtime.txt` holds the
same value with no trailing newline, which Netlify requires.

---

## Netlify and GitHub Pages together

They can both run; they do not conflict.

| | Netlify | GitHub Pages |
|---|---|---|
| Trigger | CLI, drop, or Git push | Push to `main`, plus daily at 06:00 IST |
| Config | `netlify.toml` | `.github/workflows/publish.yml` |
| Headers, redirects | Yes | Ignored — the files sit there inert |
| Address | `mtc-plan.netlify.app` | `<user>.github.io/maples-tech-club` |

Netlify gives the better URL to hand to a Principal. If you only want one, the
GitHub Actions workflow can be deleted without affecting anything else.
