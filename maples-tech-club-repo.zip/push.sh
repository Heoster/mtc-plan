#!/usr/bin/env bash
# Push this project to GitHub.
#
#   ./push.sh https://github.com/<you>/<repo>.git
#
# The token is read from the GITHUB_TOKEN environment variable and is used
# only for the one push. It is never written into .git/config or to disk:
#
#   GITHUB_TOKEN=ghp_xxx ./push.sh https://github.com/you/maples-tech-club.git
#
# Needs a fine-grained or classic token with "repo" scope, plus "workflow"
# scope, because this repository contains .github/workflows/publish.yml and
# GitHub refuses a push that adds a workflow file without it.

set -euo pipefail
cd "$(dirname "$0")"

URL="${1:-}"
[ -n "$URL" ] || { echo "usage: GITHUB_TOKEN=... ./push.sh https://github.com/<you>/<repo>.git" >&2; exit 2; }
[ -n "${GITHUB_TOKEN:-}" ] || { echo "error: GITHUB_TOKEN is not set" >&2; exit 2; }

# .git/config is not kept in workspace snapshots, so re-establish it each time.
git config user.name  "${GIT_NAME:-Harsh}"
git config user.email "${GIT_EMAIL:-harsh@mapleskhatauli.com}"
git remote remove origin 2>/dev/null || true
git remote add origin "$URL"

AUTH="$(printf '%s' "$URL" | sed -E "s#https://#https://x-access-token:${GITHUB_TOKEN}@#")"
git push -u "$AUTH" main "$@" 2>&1 | sed "s/${GITHUB_TOKEN}/***/g"

echo
echo "Pushed. Now switch Pages on:"
echo "  ${URL%.git}/settings/pages  ->  Source: GitHub Actions"
echo "Then watch the first build at:"
echo "  ${URL%.git}/actions"
