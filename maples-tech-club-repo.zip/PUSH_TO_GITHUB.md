# Putting this on GitHub

The repository is already made. Three commits, branch `main`, 20 files tracked.
Nothing here needs to be built or fixed first — it only needs pushing.

---

## Step 1 — make the empty repository

Go to <https://github.com/new>

| Field | Value |
|---|---|
| Repository name | `maples-tech-club` |
| Visibility | **Public** |
| Add a README | **no** |
| Add .gitignore | **no** |
| Add a licence | **no** |

Those three must be left off. If GitHub puts a README in, the repository starts
with a commit of its own and the first push is rejected as a non-fast-forward.

Copy the URL it shows you. It looks like:

    https://github.com/<your-username>/maples-tech-club.git

---

## Step 2 — make a token

<https://github.com/settings/tokens> → **Generate new token (classic)**

Tick exactly two scopes:

- **`repo`** — to write to the repository
- **`workflow`** — needed because this project contains
  `.github/workflows/publish.yml`. Without it GitHub rejects the push with
  *"refusing to allow a Personal Access Token to create or update workflow"*.

Set the expiry to 7 days. You can delete the token the moment the push is done.

---

## Step 3 — push

From the folder containing `push.sh`:

```bash
GITHUB_TOKEN=ghp_your_token_here ./push.sh https://github.com/<you>/maples-tech-club.git
```

`push.sh` re-applies the git identity, sets `origin`, and pushes `main`. The
token is used for that one command only — it is never written into
`.git/config` and it is masked out of the output.

If `./push.sh` will not run, `chmod +x push.sh` first, or call it as
`bash push.sh ...`.

### Doing it by hand instead

```bash
git remote add origin https://github.com/<you>/maples-tech-club.git
git push -u origin main
```

Git will prompt for a username and a password. The password is **the token**,
not your GitHub account password — GitHub stopped accepting account passwords
over HTTPS in 2021.

---

## Step 4 — switch the live site on

    https://github.com/<you>/maples-tech-club/settings/pages

Under **Source** choose **GitHub Actions**. Do not choose "Deploy from a
branch"; the workflow in this repository publishes an artifact, not a branch.

The site then appears at:

    https://<you>.github.io/maples-tech-club/

The first build takes two or three minutes. Watch it at
`.../actions`. The workflow also reruns every day at 06:00 India time, which is
what keeps the date on the PDF from going stale.

**Public is required.** GitHub Pages on a private repository needs a paid plan.
On a free account a private repo will push fine but the site will never
publish.

---

## If you would rather not use a token at all

Two offline copies are sitting next to this file:

- **`maples-tech-club.bundle`** — the whole repository, history included. Clone
  straight out of it:

  ```bash
  git clone maples-tech-club.bundle maples-tech-club
  cd maples-tech-club
  git remote set-url origin https://github.com/<you>/maples-tech-club.git
  git push -u origin main
  ```

- **`maples-tech-club-repo.zip`** — just the files, no git history, for
  uploading through GitHub's web "upload files" button. Note that the web
  uploader **will not accept `.github/workflows/publish.yml`** — GitHub blocks
  workflow files from the browser uploader. Add that one file afterwards with
  *Add file → Create new file*, or the daily rebuild will not run.

---

## What is in the repository

| File | What it is |
|---|---|
| `build_pdf.py` | The 12-page application to the Principal. ReportLab. |
| `build_site.py` | The six-page website. Rebuilds the PDF first. |
| `build_poster.py` | Four A3 posters — dark and print, PDF and PNG. Playwright. |
| `serve.py` | Local preview on port 8080. |
| `maples-tech-club/` | The built site, as published. |
| `.github/workflows/publish.yml` | Rebuilds and republishes on push and daily. |

The `*.bak` working copies of the build scripts are deliberately left out by
`.gitignore`. They are scratch files, not part of the project.
