#!/usr/bin/env bash
#
# Deploy the Maples Tech Club site to Netlify.
#
#   Project : mtc-plan
#   Owner   : CODEEX
#   Site ID : f0cefa6c-f197-4429-89cf-e4790a1675cd
#
# Usage
#   NETLIFY_AUTH_TOKEN=xxxxx ./deploy-netlify.sh          # draft preview URL
#   NETLIFY_AUTH_TOKEN=xxxxx ./deploy-netlify.sh --prod   # publish for real
#
# Get a token at:  https://app.netlify.com/user/applications#personal-access-tokens
#
# This builds locally and uploads the finished folder with --no-build. That is
# deliberate. A manual Netlify deploy does not run a build command anyway, and
# building here means a broken build fails on your machine instead of taking
# the live site down.

set -euo pipefail
cd "$(dirname "$0")"

SITE_ID="f0cefa6c-f197-4429-89cf-e4790a1675cd"
PUBLISH_DIR="maples-tech-club"

PROD=""
MSG="Manual deploy"
for a in "$@"; do
  case "$a" in
    --prod) PROD="--prod"; MSG="Production deploy" ;;
    *) MSG="$a" ;;
  esac
done

if [ -z "${NETLIFY_AUTH_TOKEN:-}" ]; then
  echo "error: NETLIFY_AUTH_TOKEN is not set." >&2
  echo "       Create one at https://app.netlify.com/user/applications#personal-access-tokens" >&2
  exit 2
fi

echo "==> Building the site and the PDF"
python3 -c 'import reportlab' 2>/dev/null || pip install -q -r requirements.txt
python3 build_site.py

echo
echo "==> Checking the build before anything is uploaded"
python3 - <<'PY'
import sys, os
from pypdf import PdfReader

out = "maples-tech-club"
need = ["index.html", "about.html", "benefits.html", "registration.html",
        "join.html", "proposal.html", "404.html",
        "Maples_Tech_Club_Proposal_Principal.pdf"]

missing = [f for f in need if not os.path.exists(os.path.join(out, f))]
if missing:
    sys.exit("missing from the build: " + ", ".join(missing))

pdf = PdfReader(os.path.join(out, "Maples_Tech_Club_Proposal_Principal.pdf"))
text = " ".join(" ".join((p.extract_text() or "") for p in pdf.pages).split())

if len(pdf.pages) != 12:
    sys.exit(f"the PDF has {len(pdf.pages)} pages, expected 12")
if "12 October 2026" not in text:
    sys.exit("the PDF is not dated 12 October 2026")
if "\u20b9" not in text:
    sys.exit("the rupee sign did not render - the DejaVu fonts in fonts/ were not picked up")

print(f"    {len(need)} files present")
print(f"    PDF {len(pdf.pages)} pages, dated 12 October 2026, rupee sign renders")
PY

echo
if [ -n "$PROD" ]; then
  echo "==> Deploying to PRODUCTION"
else
  echo "==> Deploying a draft (add --prod to publish)"
fi

npx --yes netlify-cli@latest deploy \
  --dir="$PUBLISH_DIR" \
  --site="$SITE_ID" \
  --auth="$NETLIFY_AUTH_TOKEN" \
  --message="$MSG" \
  --no-build \
  $PROD
